package com.devappcorp.organiza.organizaapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrganizaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
