insert into evento (nome, sigla, descricao) values ("evento 1", "e1", "primeiro evento");
insert into evento (nome, sigla, descricao) values ("evento 2", "e2", "primeiro evento");
insert into evento (nome, sigla, descricao) values ("evento 3", "e3", "primeiro evento");

insert into organiza.atividade (nome, tipo, descricao, data_atv, horario_inicial, horario_final) values ("atividade 011", "primeira atividade", "adasdasds", "2019-01-01", "10:00:00", "11:00:00");