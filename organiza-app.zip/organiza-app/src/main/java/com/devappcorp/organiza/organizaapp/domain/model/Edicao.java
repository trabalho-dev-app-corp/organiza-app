package com.devappcorp.organiza.organizaapp.domain.model;

public class Edicao {
    
}
