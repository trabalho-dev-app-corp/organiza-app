package com.devappcorp.organiza.organizaapp.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.devappcorp.organiza.organizaapp.domain.model.Espaco;

public interface EspacoRepository extends JpaRepository<Espaco, Long>{
    
}
