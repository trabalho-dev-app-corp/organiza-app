package com.devappcorp.organiza.organizaapp.domain.model;

import lombok.Data;

@Data
public class LoginUsuario {
    private String login;
    private String senha;
}
