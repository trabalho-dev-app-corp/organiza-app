# organiza-app

Link para o swagger: http://localhost:8080/swagger-ui.html 
PS: Tem que cadastrar um usuário na API para logar no site
